// src/app/join/[code]/page.tsx
'use client';
import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useGameStore } from '@/store/gameStore';
import { useSocket } from '@/hooks/useSocket';

export default function JoinPage({ params }: { params: { code: string } }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const socket = useSocket();
  const store = useGameStore();
  const [status, setStatus] = useState<'checking' | 'joining' | 'notfound'>('checking');
  const [team, setTeam] = useState<'red' | 'blue' | null>(null);
  const nickname = searchParams.get('nickname') || 'Player';

  useEffect(() => {
    const checkRoom = async () => {
      const res = await fetch(`/api/rooms/${params.code}`);
      if (!res.ok) { setStatus('notfound'); return; }
      setStatus('joining');
    };
    checkRoom();
  }, [params.code]);

  const joinWithTeam = (selectedTeam: 'red' | 'blue') => {
    setTeam(selectedTeam);
    store.setNickname(nickname);
    store.setMyId(socket.id || '');
    store.setIsHost(false);
    store.setRoomCode(params.code);

    socket.emit('join_room', {
      roomCode: params.code,
      nickname,
      role: 'player',
    });

    socket.emit('join_team', { roomCode: params.code, team: selectedTeam });
    router.push(`/game/${params.code}?role=player&nickname=${encodeURIComponent(nickname)}`);
  };

  if (status === 'checking') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-white/50">جاري التحقق من الغرفة...</p>
        </div>
      </div>
    );
  }

  if (status === 'notfound') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center glass-card p-8 rounded-2xl max-w-sm">
          <div className="text-5xl mb-4">😕</div>
          <h2 className="text-xl font-bold mb-2">الغرفة غير موجودة</h2>
          <p className="text-white/50 mb-6">تحقق من الرمز وحاول مجدداً</p>
          <button onClick={() => router.push('/')} className="btn-primary w-full">العودة للرئيسية</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6 rtl font-arabic">
      <div className="max-w-md w-full text-center space-y-8">
        <div>
          <div className="text-6xl mb-4">👋</div>
          <h1 className="text-3xl font-bold text-white mb-2">مرحباً، {nickname}!</h1>
          <p className="text-white/50">اختر فريقك للانضمام للغرفة <span className="font-mono text-amber-400">{params.code}</span></p>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => joinWithTeam('red')}
            className="aspect-square flex flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-red-600 to-red-800 hover:from-red-500 hover:to-red-700 transition-all hover:scale-105 active:scale-95 border-2 border-red-500/50 shadow-lg shadow-red-500/20 p-6"
          >
            <span className="text-5xl mb-3">🔴</span>
            <span className="text-xl font-bold text-white">الفريق الأحمر</span>
            <span className="text-red-200/70 text-sm mt-1">يصل أفقياً</span>
          </button>

          <button
            onClick={() => joinWithTeam('blue')}
            className="aspect-square flex flex-col items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-blue-800 hover:from-blue-500 hover:to-blue-700 transition-all hover:scale-105 active:scale-95 border-2 border-blue-500/50 shadow-lg shadow-blue-500/20 p-6"
          >
            <span className="text-5xl mb-3">🔵</span>
            <span className="text-xl font-bold text-white">الفريق الأزرق</span>
            <span className="text-blue-200/70 text-sm mt-1">يصل عمودياً</span>
          </button>
        </div>
      </div>
    </div>
  );
}
