// src/app/api/questions/[id]/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyToken, getTokenFromCookies } from '@/lib/auth';

function getHost(req: NextRequest) {
  const cookie = getTokenFromCookies(req.headers.get('cookie'));
  const header = req.headers.get('authorization')?.replace('Bearer ', '');
  return verifyToken(cookie || header || '');
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  const host = getHost(req);
  if (!host) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const { questionAr, questionEn, answerAr, answerEn, category, difficulty, firstLetter } = body;

  const question = await prisma.question.findFirst({
    where: { id: params.id, hostId: host.hostId },
  });
  if (!question) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const updated = await prisma.question.update({
    where: { id: params.id },
    data: { questionAr, questionEn, answerAr, answerEn, category, difficulty, firstLetter },
  });

  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const host = getHost(req);
  if (!host) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const question = await prisma.question.findFirst({
    where: { id: params.id, hostId: host.hostId },
  });
  if (!question) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  // Delete related records first
  await prisma.usedQuestion.deleteMany({ where: { questionId: params.id } });
  await prisma.question.delete({ where: { id: params.id } });

  return NextResponse.json({ success: true });
}
