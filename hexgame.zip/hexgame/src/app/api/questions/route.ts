// src/app/api/questions/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyToken, getTokenFromCookies } from '@/lib/auth';

function getHost(req: NextRequest) {
  const cookie = getTokenFromCookies(req.headers.get('cookie'));
  const header = req.headers.get('authorization')?.replace('Bearer ', '');
  return verifyToken(cookie || header || '');
}

export async function GET(req: NextRequest) {
  const host = getHost(req);
  if (!host) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const filter = searchParams.get('filter'); // all | used | unused
  const category = searchParams.get('category');
  const sessionId = searchParams.get('sessionId');

  const where: any = { hostId: host.hostId };
  if (category) where.category = category;

  const questions = await prisma.question.findMany({
    where,
    include: {
      usedInGames: {
        where: sessionId ? { sessionId } : undefined,
        select: { id: true, sessionId: true, correct: true },
      },
    },
    orderBy: { createdAt: 'desc' },
  });

  const enriched = questions.map(q => ({
    ...q,
    usedInSession: sessionId ? q.usedInGames.some(u => u.sessionId === sessionId) : false,
    usedHistorically: q.usedInGames.length > 0,
    usedCount: q.usedInGames.length,
  }));

  let result = enriched;
  if (filter === 'used') result = enriched.filter(q => q.usedHistorically);
  if (filter === 'unused') result = enriched.filter(q => !q.usedHistorically);

  return NextResponse.json(result);
}

export async function POST(req: NextRequest) {
  const host = getHost(req);
  if (!host) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body = await req.json();
  const { questionAr, questionEn, answerAr, answerEn, category, difficulty, firstLetter, tags } = body;

  if (!questionAr || !questionEn || !answerAr || !answerEn || !category) {
    return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
  }

  const question = await prisma.question.create({
    data: {
      hostId: host.hostId,
      questionAr, questionEn,
      answerAr, answerEn,
      category,
      difficulty: difficulty || 'medium',
      firstLetter: firstLetter || answerEn[0]?.toUpperCase(),
      tags: tags ? JSON.stringify(tags) : null,
    },
  });

  return NextResponse.json(question, { status: 201 });
}
