// src/app/api/rooms/[code]/route.ts
import { NextRequest, NextResponse } from 'next/server';

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3001';

export async function GET(req: NextRequest, { params }: { params: { code: string } }) {
  try {
    const res = await fetch(`${SOCKET_URL}/api/rooms/${params.code}`);
    const data = await res.json();
    return NextResponse.json(data, { status: res.status });
  } catch {
    return NextResponse.json({ error: 'Socket server not reachable' }, { status: 503 });
  }
}
