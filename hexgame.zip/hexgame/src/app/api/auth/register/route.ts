// src/app/api/auth/register/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { hashPassword, signToken } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const { email, password, name } = await req.json();
    
    const existing = await prisma.host.findUnique({ where: { email } });
    if (existing) return NextResponse.json({ error: 'Email already registered' }, { status: 409 });
    
    const passwordHash = await hashPassword(password);
    const host = await prisma.host.create({ data: { email, passwordHash, name } });
    
    const token = signToken({ hostId: host.id, email: host.email });
    return NextResponse.json({ hostId: host.id, name: host.name, token });
  } catch (e) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
