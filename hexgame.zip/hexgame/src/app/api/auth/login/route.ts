// src/app/api/auth/login/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { verifyPassword, signToken } from '@/lib/auth';

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();
    
    const host = await prisma.host.findUnique({ where: { email } });
    if (!host) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    
    const valid = await verifyPassword(password, host.passwordHash);
    if (!valid) return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
    
    const token = signToken({ hostId: host.id, email: host.email });
    
    const response = NextResponse.json({ hostId: host.id, name: host.name, token });
    response.cookies.set('auth_token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60,
    });
    
    return response;
  } catch (e) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 });
  }
}
