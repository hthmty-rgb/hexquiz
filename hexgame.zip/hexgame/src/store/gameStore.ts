// src/store/gameStore.ts
import { create } from 'zustand';
import { GameState, GameSettings, Language, HexGrid, Player, Teams, Question, QuestionHistoryEntry, TeamColor } from '@/types';

const defaultSettings: GameSettings = {
  boardSize: 'medium',
  language: 'AR',
  categories: [],
  difficulty: 'all',
  timerSeconds: 30,
  buzzMode: true,
  showLetterHint: true,
  showQuestionToAll: true,
  soundEnabled: true,
};

interface GameStore extends GameState {
  setRoomCode: (code: string) => void;
  setSessionId: (id: string) => void;
  setHostId: (id: string) => void;
  setGrid: (grid: HexGrid) => void;
  setSettings: (settings: Partial<GameSettings>) => void;
  setPlayers: (players: Player[]) => void;
  setTeams: (teams: Teams) => void;
  setStatus: (status: GameState['status']) => void;
  setCurrentQuestion: (q: Question | null) => void;
  setCurrentCell: (id: number | null) => void;
  setBuzzedPlayer: (id: string | null) => void;
  setWinner: (team: TeamColor | null) => void;
  setHistory: (history: QuestionHistoryEntry[]) => void;
  setLanguage: (lang: Language) => void;
  setIsHost: (v: boolean) => void;
  setMyId: (id: string) => void;
  setNickname: (n: string) => void;
  reset: () => void;
}

const initialState: GameState = {
  roomCode: null,
  sessionId: null,
  hostId: null,
  grid: null,
  settings: defaultSettings,
  players: [],
  teams: { red: [], blue: [] },
  status: 'lobby',
  currentQuestion: null,
  currentCell: null,
  buzzedPlayer: null,
  winner: null,
  questionHistory: [],
  language: 'AR',
  isHost: false,
  myId: null,
  nickname: null,
};

export const useGameStore = create<GameStore>((set) => ({
  ...initialState,
  setRoomCode: (code) => set({ roomCode: code }),
  setSessionId: (id) => set({ sessionId: id }),
  setHostId: (id) => set({ hostId: id }),
  setGrid: (grid) => set({ grid }),
  setSettings: (settings) => set((s) => ({ settings: { ...s.settings, ...settings } })),
  setPlayers: (players) => set({ players }),
  setTeams: (teams) => set({ teams }),
  setStatus: (status) => set({ status }),
  setCurrentQuestion: (q) => set({ currentQuestion: q }),
  setCurrentCell: (id) => set({ currentCell: id }),
  setBuzzedPlayer: (id) => set({ buzzedPlayer: id }),
  setWinner: (team) => set({ winner: team }),
  setHistory: (history) => set({ questionHistory: history }),
  setLanguage: (lang) => set({ language: lang }),
  setIsHost: (v) => set({ isHost: v }),
  setMyId: (id) => set({ myId: id }),
  setNickname: (n) => set({ nickname: n }),
  reset: () => set(initialState),
}));
