// src/components/QRCodePanel.tsx
'use client';
import { useEffect, useState } from 'react';

interface Props {
  roomCode: string;
  onClose: () => void;
}

export default function QRCodePanel({ roomCode, onClose }: Props) {
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const joinUrl = `${window.location.origin}/join/${roomCode}`;

  useEffect(() => {
    // Generate QR using API endpoint
    fetch(`/api/qr?url=${encodeURIComponent(joinUrl)}`)
      .then(r => r.json())
      .then(d => setQrDataUrl(d.dataUrl))
      .catch(() => {});
  }, [joinUrl]);

  const copyLink = () => {
    navigator.clipboard.writeText(joinUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="glass-card p-8 rounded-2xl text-center space-y-4 max-w-xs">
      <h3 className="text-lg font-bold text-white">مسح للانضمام / Scan to Join</h3>
      
      <div className="font-mono text-3xl font-bold text-amber-400 tracking-widest">{roomCode}</div>
      
      {qrDataUrl ? (
        <div className="bg-white p-3 rounded-xl inline-block">
          <img src={qrDataUrl} alt="QR Code" className="w-48 h-48" />
        </div>
      ) : (
        <div className="w-48 h-48 bg-white/10 rounded-xl animate-pulse mx-auto" />
      )}

      <p className="text-white/40 text-sm break-all">{joinUrl}</p>

      <div className="grid grid-cols-2 gap-3">
        <button onClick={copyLink} className="btn-ghost text-sm py-2">
          {copied ? '✓ Copied!' : '📋 Copy Link'}
        </button>
        <button onClick={onClose} className="btn-ghost text-sm py-2">
          ✕ Close
        </button>
      </div>
    </div>
  );
}
