// src/components/QuestionHistoryPanel.tsx
'use client';
import { useGameStore } from '@/store/gameStore';

export default function QuestionHistoryPanel() {
  const history = useGameStore(s => s.questionHistory);
  const language = useGameStore(s => s.settings.language);
  const isAr = language !== 'EN';

  return (
    <div className="flex flex-col h-full">
      <div className="px-4 py-3 border-b border-white/10">
        <h3 className="text-sm font-semibold text-white/60">
          {isAr ? '📋 سجل الأسئلة' : '📋 Question History'}
        </h3>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {history.length === 0 ? (
          <p className="text-center text-white/20 text-xs py-8">
            {isAr ? 'لا يوجد سجل بعد' : 'No history yet'}
          </p>
        ) : [...history].reverse().map((entry, i) => (
          <div key={i} className={`p-3 rounded-xl text-xs space-y-1 ${
            entry.correct ? 'bg-green-900/20 border border-green-500/20' : 'bg-red-900/20 border border-red-500/20'
          }`}>
            <div className="flex items-start justify-between gap-2">
              <span className={entry.correct ? 'text-green-400' : 'text-red-400'}>
                {entry.correct ? '✓' : '✗'}
              </span>
              <span className="text-white/30 text-xs flex-shrink-0">
                {new Date(entry.askedAt).toLocaleTimeString()}
              </span>
            </div>
            <p className={`text-white/70 ${isAr ? 'font-arabic text-right' : ''}`}>
              {language === 'EN' ? entry.questionEn : entry.questionAr}
            </p>
            <p className={`font-medium ${entry.correct ? 'text-green-300' : 'text-white/40'}`}>
              → {language === 'EN' ? entry.answerEn : entry.answerAr}
            </p>
            {entry.teamAnswered && (
              <div className={`text-xs ${entry.teamAnswered === 'red' ? 'text-red-400' : 'text-blue-400'}`}>
                {isAr ? `الفريق ${entry.teamAnswered === 'red' ? 'الأحمر' : 'الأزرق'}` : `${entry.teamAnswered} team`}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
