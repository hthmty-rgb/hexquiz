// src/components/QuestionPanel.tsx
'use client';
import { useState } from 'react';
import { useGameStore } from '@/store/gameStore';
import { useSocket } from '@/hooks/useSocket';

interface Props {
  roomCode: string;
  isHost: boolean;
  compact?: boolean;
}

export default function QuestionPanel({ roomCode, isHost, compact }: Props) {
  const socket = useSocket();
  const question = useGameStore(s => s.currentQuestion);
  const buzzedPlayer = useGameStore(s => s.buzzedPlayer);
  const players = useGameStore(s => s.players);
  const teams = useGameStore(s => s.teams);
  const language = useGameStore(s => s.settings.language);
  const buzzMode = useGameStore(s => s.settings.buzzMode);
  const showToAll = useGameStore(s => s.settings.showQuestionToAll);
  const myId = useGameStore(s => s.myId);
  const [showAnswer, setShowAnswer] = useState(false);

  const isAr = language !== 'EN';
  const buzzedPlayerData = players.find(p => p.id === buzzedPlayer);
  const myTeam = teams.red.includes(myId || '') ? 'red' : teams.blue.includes(myId || '') ? 'blue' : null;
  const canBuzz = !isHost && buzzMode && !buzzedPlayer && !!question;

  const handleBuzz = () => {
    if (!canBuzz) return;
    socket.emit('buzz_in', { roomCode });
  };

  const markCorrect = (team: 'red' | 'blue') => {
    socket.emit('answer_result', { roomCode, correct: true, team });
    setShowAnswer(false);
  };

  const markIncorrect = () => {
    socket.emit('answer_result', { roomCode, correct: false, team: null });
    setShowAnswer(false);
  };

  const skip = () => {
    socket.emit('skip_question', { roomCode });
    setShowAnswer(false);
  };

  if (!question) {
    return (
      <div className={`flex-1 flex items-center justify-center p-6 ${compact ? 'p-4' : ''}`}>
        <p className={`text-white/20 text-sm text-center ${isAr ? 'font-arabic' : ''}`}>
          {isHost
            ? (isAr ? 'انقر على خلية لبدء السؤال' : 'Click a cell to start')
            : (isAr ? 'في انتظار المضيف...' : 'Waiting for host...')}
        </p>
      </div>
    );
  }

  const qText = language === 'EN' ? question.questionEn : language === 'AR' ? question.questionAr : `${question.questionAr}\n${question.questionEn}`;
  const aText = language === 'EN' ? question.answerEn : language === 'AR' ? question.answerAr : `${question.answerAr} / ${question.answerEn}`;

  const shouldShowQuestion = isHost || showToAll;

  return (
    <div className={`flex flex-col p-4 space-y-4 ${compact ? 'p-3 space-y-3' : ''}`}>
      {/* Category badge */}
      <div className="flex items-center gap-2">
        <span className="badge bg-purple-500/20 text-purple-300 border border-purple-500/30">
          {question.category}
        </span>
        <span className={`badge ${question.difficulty === 'easy' ? 'bg-green-500/20 text-green-300 border-green-500/30' : question.difficulty === 'hard' ? 'bg-red-500/20 text-red-300 border-red-500/30' : 'bg-amber-500/20 text-amber-300 border-amber-500/30'}`}>
          {question.difficulty}
        </span>
      </div>

      {/* Question text */}
      {shouldShowQuestion ? (
        <div className={`glass-card p-4 rounded-xl ${isAr ? 'text-right font-arabic' : ''}`}>
          <p className={`text-white font-medium leading-relaxed ${compact ? 'text-sm' : 'text-base'}`}>
            {language === 'BOTH' ? (
              <>
                <span className="block font-arabic">{question.questionAr}</span>
                <span className="block text-white/60 text-sm mt-1">{question.questionEn}</span>
              </>
            ) : qText}
          </p>
        </div>
      ) : (
        <div className="glass-card p-4 rounded-xl text-center">
          <p className="text-white/30 text-sm">{isAr ? 'انتظر المضيف...' : 'Waiting for host...'}</p>
        </div>
      )}

      {/* Buzz indicator */}
      {buzzedPlayer && (
        <div className={`text-center p-3 rounded-xl border ${
          buzzedPlayer === myId
            ? 'border-green-500/50 bg-green-500/10 text-green-400'
            : 'border-amber-500/50 bg-amber-500/10 text-amber-400'
        }`}>
          <span className="font-bold">⚡ {buzzedPlayerData?.nickname || 'Player'}</span>
          <span className="text-white/50 text-sm ml-2">{isAr ? 'يجيب!' : 'is answering!'}</span>
        </div>
      )}

      {/* Answer (host only) */}
      {isHost && (
        <>
          {showAnswer && (
            <div className={`p-4 rounded-xl bg-green-900/30 border border-green-500/30 ${isAr ? 'text-right font-arabic' : ''}`}>
              <p className="text-xs text-green-400 mb-1">{isAr ? 'الإجابة' : 'Answer'}</p>
              <p className="text-green-300 font-bold text-lg">{aText}</p>
            </div>
          )}

          <div className="space-y-2">
            <button onClick={() => setShowAnswer(!showAnswer)} className="w-full btn-ghost text-sm py-2">
              {showAnswer ? (isAr ? '🙈 إخفاء الإجابة' : '🙈 Hide Answer') : (isAr ? '👁 إظهار الإجابة' : '👁 Show Answer')}
            </button>
            
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => markCorrect('red')}
                className="py-3 rounded-xl font-medium bg-red-600/20 border border-red-500/30 text-red-400 hover:bg-red-600/40 transition-all text-sm"
              >
                ✓ {isAr ? 'أحمر صح' : 'Red ✓'}
              </button>
              <button
                onClick={() => markCorrect('blue')}
                className="py-3 rounded-xl font-medium bg-blue-600/20 border border-blue-500/30 text-blue-400 hover:bg-blue-600/40 transition-all text-sm"
              >
                ✓ {isAr ? 'أزرق صح' : 'Blue ✓'}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button onClick={markIncorrect} className="py-2 rounded-xl text-sm bg-white/5 hover:bg-white/10 text-white/50 transition-all">
                ✗ {isAr ? 'خطأ' : 'Wrong'}
              </button>
              <button onClick={skip} className="py-2 rounded-xl text-sm bg-white/5 hover:bg-white/10 text-white/50 transition-all">
                ⏭ {isAr ? 'تخطي' : 'Skip'}
              </button>
            </div>
          </div>
        </>
      )}

      {/* Player buzz button */}
      {!isHost && buzzMode && (
        <button
          onClick={handleBuzz}
          disabled={!!buzzedPlayer || !question}
          className={`w-full py-5 rounded-2xl font-bold text-xl transition-all ${
            buzzedPlayer === myId
              ? 'bg-green-600 text-white cursor-not-allowed'
              : buzzedPlayer
              ? 'bg-white/10 text-white/30 cursor-not-allowed'
              : 'bg-gradient-to-r from-amber-500 to-orange-500 text-white hover:scale-105 active:scale-95 shadow-lg shadow-amber-500/30 buzz-animate'
          }`}
        >
          {buzzedPlayer === myId
            ? (isAr ? '✓ أنت تجيب!' : '✓ You buzzed!')
            : buzzedPlayer
            ? (isAr ? `⚡ ${buzzedPlayerData?.nickname}` : `⚡ ${buzzedPlayerData?.nickname}`)
            : (isAr ? '⚡ اضغط للإجابة!' : '⚡ Buzz In!')}
        </button>
      )}
    </div>
  );
}
