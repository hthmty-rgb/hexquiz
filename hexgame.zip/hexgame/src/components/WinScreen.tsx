// src/components/WinScreen.tsx
'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useGameStore } from '@/store/gameStore';
import { useSocket } from '@/hooks/useSocket';
import { TeamColor } from '@/types';

interface Props {
  winner: TeamColor;
  isHost: boolean;
  roomCode: string;
}

export default function WinScreen({ winner, isHost, roomCode }: Props) {
  const router = useRouter();
  const socket = useSocket();
  const store = useGameStore();
  const isAr = store.settings.language !== 'EN';
  const [confetti, setConfetti] = useState<{ x: number; y: number; color: string; delay: number }[]>([]);

  useEffect(() => {
    const pieces = Array.from({ length: 50 }, (_, i) => ({
      x: Math.random() * 100,
      y: -10 - Math.random() * 20,
      color: winner === 'red'
        ? ['#EF4444', '#F97316', '#FCD34D'][Math.floor(Math.random() * 3)]
        : ['#3B82F6', '#8B5CF6', '#06B6D4'][Math.floor(Math.random() * 3)],
      delay: Math.random() * 2,
    }));
    setConfetti(pieces);
  }, [winner]);

  const playAgain = () => {
    socket.emit('reset_game', { roomCode });
  };

  const redCount = store.grid?.cells.filter(c => c.owner === 'red').length || 0;
  const blueCount = store.grid?.cells.filter(c => c.owner === 'blue').length || 0;

  return (
    <div className={`min-h-screen flex items-center justify-center p-6 relative overflow-hidden ${isAr ? 'rtl font-arabic' : 'ltr'}`}>
      {/* Confetti */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        {confetti.map((piece, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 rounded-sm"
            style={{
              left: `${piece.x}%`,
              top: `${piece.y}%`,
              background: piece.color,
              animation: `confettiDrop ${2 + Math.random() * 2}s ${piece.delay}s linear infinite`,
            }}
          />
        ))}
      </div>

      {/* Glowing background */}
      <div
        className="fixed inset-0 opacity-10"
        style={{
          background: winner === 'red'
            ? 'radial-gradient(ellipse at center, #EF4444 0%, transparent 70%)'
            : 'radial-gradient(ellipse at center, #3B82F6 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 text-center max-w-md w-full">
        {/* Trophy */}
        <div className="text-9xl mb-4 animate-bounce-in">🏆</div>
        
        <h1 className="text-5xl font-bold mb-2" style={{ color: winner === 'red' ? '#EF4444' : '#3B82F6' }}>
          {isAr
            ? `الفريق ${winner === 'red' ? 'الأحمر' : 'الأزرق'}`
            : `${winner === 'red' ? 'Red' : 'Blue'} Team`}
        </h1>
        <p className="text-2xl text-white/70 mb-8">
          {isAr ? 'فاز! 🎉' : 'Wins! 🎉'}
        </p>

        {/* Scores */}
        <div className="glass-card p-6 rounded-2xl mb-8">
          <div className="grid grid-cols-3 items-center gap-4">
            <div className="text-center">
              <div className="text-4xl font-bold text-red-400">{redCount}</div>
              <div className="text-white/40 text-sm mt-1">{isAr ? 'أحمر' : 'Red'}</div>
            </div>
            <div className="text-white/20 text-2xl">vs</div>
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-400">{blueCount}</div>
              <div className="text-white/40 text-sm mt-1">{isAr ? 'أزرق' : 'Blue'}</div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {isHost && (
            <button onClick={playAgain} className="w-full btn-primary py-4 text-lg rounded-2xl">
              🔄 {isAr ? 'العب مجدداً' : 'Play Again'}
            </button>
          )}
          <button onClick={() => router.push('/')} className="w-full btn-ghost py-4 text-lg rounded-2xl">
            🏠 {isAr ? 'الرئيسية' : 'Home'}
          </button>
        </div>
      </div>
    </div>
  );
}
