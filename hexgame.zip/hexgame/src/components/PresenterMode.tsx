// src/components/PresenterMode.tsx
'use client';
import { useGameStore } from '@/store/gameStore';
import HexBoard from './HexBoard';

interface Props {
  onExit: () => void;
}

export default function PresenterMode({ onExit }: Props) {
  const store = useGameStore();
  const question = store.currentQuestion;
  const language = store.settings.language;
  const isAr = language !== 'EN';
  const roomCode = store.roomCode || '';

  const redCount = store.grid?.cells.filter(c => c.owner === 'red').length || 0;
  const blueCount = store.grid?.cells.filter(c => c.owner === 'blue').length || 0;

  return (
    <div className={`min-h-screen bg-gray-950 flex flex-col ${isAr ? 'rtl font-arabic' : 'ltr'}`}>
      {/* Presenter top bar */}
      <div className="flex items-center justify-between px-8 py-4 bg-black/50">
        <div className="flex items-center gap-8">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-red-400 bg-clip-text text-transparent">
            {isAr ? 'هيكس الألغاز' : 'HexQuiz'}
          </h1>
          <div className="font-mono text-amber-400 font-bold text-xl tracking-widest">{roomCode}</div>
        </div>

        <div className="flex items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-red-500" />
            <span className="text-5xl font-bold text-red-400">{redCount}</span>
          </div>
          <span className="text-white/20 text-2xl">vs</span>
          <div className="flex items-center gap-3">
            <span className="text-5xl font-bold text-blue-400">{blueCount}</span>
            <div className="w-4 h-4 rounded-full bg-blue-500" />
          </div>
        </div>

        <button onClick={onExit} className="btn-ghost text-sm py-2 px-4">
          {isAr ? 'خروج' : 'Exit'}
        </button>
      </div>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Board - larger for TV */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="scale-125 origin-center">
            <HexBoard roomCode={roomCode} isHost={false} />
          </div>
        </div>

        {/* Question sidebar */}
        {question && (
          <div className="w-96 border-l border-white/10 p-6 flex flex-col justify-center space-y-4">
            <div className="flex gap-2">
              <span className="badge bg-purple-500/20 text-purple-300 border border-purple-500/30 text-sm">{question.category}</span>
              <span className={`badge text-sm ${question.difficulty === 'easy' ? 'bg-green-500/20 text-green-300 border-green-500/30' : question.difficulty === 'hard' ? 'bg-red-500/20 text-red-300 border-red-500/30' : 'bg-amber-500/20 text-amber-300 border-amber-500/30'}`}>
                {question.difficulty}
              </span>
            </div>
            
            <div className="glass-card p-6 rounded-2xl">
              <p className={`text-2xl text-white font-medium leading-relaxed ${isAr ? 'font-arabic text-right' : ''}`}>
                {language === 'BOTH' ? (
                  <>
                    <span className="block font-arabic text-right mb-2">{question.questionAr}</span>
                    <span className="block text-white/60 text-lg ltr text-left">{question.questionEn}</span>
                  </>
                ) : language === 'AR' ? question.questionAr : question.questionEn}
              </p>
            </div>

            {store.buzzedPlayer && (
              <div className="p-4 rounded-xl border border-amber-500/50 bg-amber-500/10 text-center">
                <span className="text-amber-400 font-bold text-xl">
                  ⚡ {store.players.find(p => p.id === store.buzzedPlayer)?.nickname}
                </span>
              </div>
            )}
          </div>
        )}

        {!question && (
          <div className="w-96 border-l border-white/10 flex items-center justify-center">
            <p className={`text-white/20 text-lg ${isAr ? 'font-arabic' : ''}`}>
              {isAr ? 'في انتظار المضيف...' : 'Waiting for host...'}
            </p>
          </div>
        )}
      </div>

      {/* Bottom - join instructions */}
      <div className="flex items-center justify-center py-4 bg-black/30 border-t border-white/5">
        <p className="text-white/30 text-sm">
          {isAr ? `انضم على الرابط أو رمز الغرفة: ${roomCode}` : `Join at the link or room code: ${roomCode}`}
        </p>
      </div>
    </div>
  );
}
