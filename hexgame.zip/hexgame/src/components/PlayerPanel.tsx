// src/components/PlayerPanel.tsx
'use client';
import { useGameStore } from '@/store/gameStore';

export default function PlayerPanel() {
  const players = useGameStore(s => s.players);
  const teams = useGameStore(s => s.teams);
  const grid = useGameStore(s => s.grid);
  const isAr = useGameStore(s => s.settings.language !== 'EN');

  const redCount = grid?.cells.filter(c => c.owner === 'red').length || 0;
  const blueCount = grid?.cells.filter(c => c.owner === 'blue').length || 0;

  const redPlayers = players.filter(p => teams.red.includes(p.id));
  const bluePlayers = players.filter(p => teams.blue.includes(p.id));

  return (
    <div className="space-y-4">
      {/* Red team */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-red-400 uppercase tracking-wider">
            {isAr ? 'الأحمر' : 'Red'}
          </h3>
          <span className="text-red-400 font-bold">{redCount}</span>
        </div>
        <div className="space-y-1">
          {redPlayers.map(p => (
            <div key={p.id} className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-red-900/20">
              <div className="w-2 h-2 rounded-full bg-red-500 flex-shrink-0" />
              <span className="text-xs text-white/70 truncate">{p.nickname}</span>
            </div>
          ))}
          {redPlayers.length === 0 && <p className="text-xs text-white/20 px-2">{isAr ? 'لا أحد' : 'Empty'}</p>}
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-white/10" />

      {/* Blue team */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xs font-bold text-blue-400 uppercase tracking-wider">
            {isAr ? 'الأزرق' : 'Blue'}
          </h3>
          <span className="text-blue-400 font-bold">{blueCount}</span>
        </div>
        <div className="space-y-1">
          {bluePlayers.map(p => (
            <div key={p.id} className="flex items-center gap-2 px-2 py-1.5 rounded-lg bg-blue-900/20">
              <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
              <span className="text-xs text-white/70 truncate">{p.nickname}</span>
            </div>
          ))}
          {bluePlayers.length === 0 && <p className="text-xs text-white/20 px-2">{isAr ? 'لا أحد' : 'Empty'}</p>}
        </div>
      </div>
    </div>
  );
}
