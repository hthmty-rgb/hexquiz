// src/components/TimerRing.tsx
'use client';
import { useEffect, useState } from 'react';
import { useGameStore } from '@/store/gameStore';

interface Props {
  seconds: number;
}

export default function TimerRing({ seconds }: Props) {
  const question = useGameStore(s => s.currentQuestion);
  const [remaining, setRemaining] = useState(seconds);
  const isAr = useGameStore(s => s.settings.language !== 'EN');

  useEffect(() => {
    if (!question) return;
    setRemaining(seconds);
    const interval = setInterval(() => {
      setRemaining(prev => {
        if (prev <= 0) { clearInterval(interval); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [question, seconds]);

  const progress = remaining / seconds;
  const circumference = 2 * Math.PI * 24;
  const dashOffset = circumference * (1 - progress);

  const color = remaining > seconds * 0.5 ? '#22C55E' : remaining > seconds * 0.25 ? '#F59E0B' : '#EF4444';

  return (
    <div className="flex items-center justify-center gap-4">
      <div className="relative w-16 h-16">
        <svg className="timer-ring w-16 h-16 -rotate-90" viewBox="0 0 56 56">
          <circle cx="28" cy="28" r="24" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="4"/>
          <circle
            cx="28" cy="28" r="24"
            fill="none"
            stroke={color}
            strokeWidth="4"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={dashOffset}
            style={{ transition: 'stroke-dashoffset 1s linear, stroke 0.5s ease' }}
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center font-bold text-lg" style={{ color }}>
          {remaining}
        </span>
      </div>
      <span className="text-white/30 text-sm">{isAr ? 'ثانية متبقية' : 'seconds'}</span>
    </div>
  );
}
