// src/components/LobbyView.tsx
'use client';
import { useEffect, useState } from 'react';
import { useGameStore } from '@/store/gameStore';
import { useSocket } from '@/hooks/useSocket';
import QRCodePanel from './QRCodePanel';

interface Props {
  roomCode: string;
  isHost: boolean;
}

export default function LobbyView({ roomCode, isHost }: Props) {
  const socket = useSocket();
  const store = useGameStore();
  const [showQR, setShowQR] = useState(false);
  const [copied, setCopied] = useState(false);

  const isAr = store.settings.language !== 'EN';
  const redPlayers = store.players.filter(p => store.teams.red.includes(p.id));
  const bluePlayers = store.players.filter(p => store.teams.blue.includes(p.id));

  const startGame = () => {
    socket.emit('start_game', { roomCode });
  };

  const copyCode = () => {
    navigator.clipboard.writeText(roomCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const assignTeam = (playerId: string, team: 'red' | 'blue') => {
    socket.emit('assign_team', { roomCode, playerId, team });
  };

  const joinLink = `${window.location.origin}/join/${roomCode}?nickname=Player`;

  return (
    <div className={`min-h-screen p-6 ${isAr ? 'rtl font-arabic' : 'ltr'}`}>
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-red-400 bg-clip-text text-transparent mb-2">
            {isAr ? 'غرفة الانتظار' : 'Game Lobby'}
          </h1>
          
          {/* Room code display */}
          <div className="inline-flex items-center gap-3 bg-white/5 border border-white/10 rounded-2xl px-6 py-3 mt-4">
            <span className="text-white/40 text-sm">{isAr ? 'رمز الغرفة' : 'Room Code'}</span>
            <span className="font-mono font-bold text-3xl text-amber-400 tracking-widest">{roomCode}</span>
            <button onClick={copyCode} className="text-white/40 hover:text-white transition-colors">
              {copied ? '✓' : '📋'}
            </button>
          </div>

          <div className="flex justify-center gap-3 mt-4">
            <button onClick={() => setShowQR(true)} className="btn-ghost text-sm py-2 px-4">
              📱 {isAr ? 'رمز QR' : 'QR Code'}
            </button>
            <button onClick={copyCode} className="btn-ghost text-sm py-2 px-4">
              🔗 {isAr ? 'نسخ الرابط' : 'Copy Link'}
            </button>
          </div>
        </div>

        {/* Teams */}
        <div className="grid grid-cols-2 gap-6 mb-8">
          {/* Red team */}
          <div className="glass-card rounded-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-red-900/50 to-red-800/30 px-4 py-3 border-b border-red-500/20">
              <h3 className="font-bold text-red-400 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-red-500" />
                {isAr ? 'الفريق الأحمر' : 'Red Team'}
                <span className="text-red-600 text-xs ml-auto">{isAr ? 'يصل أفقياً ←→' : 'Connect horizontal ←→'}</span>
              </h3>
            </div>
            <div className="p-4 space-y-2 min-h-[120px]">
              {redPlayers.length === 0 ? (
                <p className="text-white/20 text-sm text-center py-4">{isAr ? 'لا يوجد لاعبون' : 'No players yet'}</p>
              ) : redPlayers.map(p => (
                <PlayerChip key={p.id} player={p} team="red" isHost={isHost} onAssign={assignTeam} />
              ))}
            </div>
          </div>

          {/* Blue team */}
          <div className="glass-card rounded-2xl overflow-hidden">
            <div className="bg-gradient-to-r from-blue-900/50 to-blue-800/30 px-4 py-3 border-b border-blue-500/20">
              <h3 className="font-bold text-blue-400 flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-blue-500" />
                {isAr ? 'الفريق الأزرق' : 'Blue Team'}
                <span className="text-blue-600 text-xs ml-auto">{isAr ? 'يصل عمودياً ↕' : 'Connect vertical ↕'}</span>
              </h3>
            </div>
            <div className="p-4 space-y-2 min-h-[120px]">
              {bluePlayers.length === 0 ? (
                <p className="text-white/20 text-sm text-center py-4">{isAr ? 'لا يوجد لاعبون' : 'No players yet'}</p>
              ) : bluePlayers.map(p => (
                <PlayerChip key={p.id} player={p} team="blue" isHost={isHost} onAssign={assignTeam} />
              ))}
            </div>
          </div>
        </div>

        {/* Unassigned players */}
        {store.players.filter(p => !store.teams.red.includes(p.id) && !store.teams.blue.includes(p.id) && p.role !== 'host').length > 0 && (
          <div className="glass-card p-4 rounded-2xl mb-6">
            <h3 className="text-white/50 text-sm mb-3">{isAr ? 'لم يختاروا فريقاً بعد' : 'Not yet assigned'}</h3>
            <div className="flex flex-wrap gap-2">
              {store.players
                .filter(p => !store.teams.red.includes(p.id) && !store.teams.blue.includes(p.id) && p.role !== 'host')
                .map(p => (
                  <div key={p.id} className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
                    <span className="text-sm text-white/70">{p.nickname}</span>
                    {isHost && (
                      <div className="flex gap-1">
                        <button onClick={() => assignTeam(p.id, 'red')} className="w-5 h-5 rounded-full bg-red-600/50 hover:bg-red-600 transition-all" />
                        <button onClick={() => assignTeam(p.id, 'blue')} className="w-5 h-5 rounded-full bg-blue-600/50 hover:bg-blue-600 transition-all" />
                      </div>
                    )}
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* Game settings summary */}
        <div className="glass-card p-4 rounded-2xl mb-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center text-sm">
            <div>
              <p className="text-white/30">{isAr ? 'الحجم' : 'Size'}</p>
              <p className="text-white font-medium">{store.settings.boardSize}</p>
            </div>
            <div>
              <p className="text-white/30">{isAr ? 'اللغة' : 'Language'}</p>
              <p className="text-white font-medium">{store.settings.language}</p>
            </div>
            <div>
              <p className="text-white/30">{isAr ? 'الوقت' : 'Timer'}</p>
              <p className="text-white font-medium">{store.settings.timerSeconds}s</p>
            </div>
            <div>
              <p className="text-white/30">{isAr ? 'الوضع' : 'Mode'}</p>
              <p className="text-white font-medium">{store.settings.buzzMode ? (isAr ? 'استجابة' : 'Buzz') : (isAr ? 'أدوار' : 'Turn')}</p>
            </div>
          </div>
        </div>

        {/* Start button (host only) */}
        {isHost && (
          <button onClick={startGame} className="w-full btn-primary py-5 text-xl rounded-2xl">
            🚀 {isAr ? 'ابدأ اللعبة!' : 'Start Game!'}
          </button>
        )}

        {!isHost && (
          <div className="text-center py-6">
            <div className="inline-flex items-center gap-3 text-white/40">
              <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              {isAr ? 'في انتظار المضيف لبدء اللعبة...' : 'Waiting for host to start...'}
            </div>
          </div>
        )}
      </div>

      {showQR && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50" onClick={() => setShowQR(false)}>
          <div onClick={e => e.stopPropagation()}>
            <QRCodePanel roomCode={roomCode} onClose={() => setShowQR(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

function PlayerChip({ player, team, isHost, onAssign }: {
  player: { id: string; nickname: string };
  team: 'red' | 'blue';
  isHost: boolean;
  onAssign: (id: string, t: 'red' | 'blue') => void;
}) {
  return (
    <div className="flex items-center justify-between bg-white/5 rounded-xl px-3 py-2">
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${team === 'red' ? 'bg-red-500' : 'bg-blue-500'}`} />
        <span className="text-sm text-white/80">{player.nickname}</span>
      </div>
      {isHost && (
        <button
          onClick={() => onAssign(player.id, team === 'red' ? 'blue' : 'red')}
          className="text-xs text-white/20 hover:text-white/50 transition-colors ml-2"
        >
          ⇄
        </button>
      )}
    </div>
  );
}
