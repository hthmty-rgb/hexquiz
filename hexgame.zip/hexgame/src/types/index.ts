// src/types/index.ts

export type Language = 'AR' | 'EN' | 'BOTH';
export type Difficulty = 'easy' | 'medium' | 'hard' | 'all';
export type TeamColor = 'red' | 'blue';
export type GameStatus = 'lobby' | 'playing' | 'finished';
export type BoardSize = 'small' | 'medium' | 'large';

export interface HexCell {
  id: number;
  row: number;
  col: number;
  owner: TeamColor | null;
  letterAr: string;
  letterEn: string;
}

export interface HexGrid {
  cells: HexCell[];
  size: number;
}

export interface Player {
  id: string;
  nickname: string;
  role: 'host' | 'player';
  hostId?: string;
}

export interface Question {
  id: string;
  questionAr: string;
  questionEn: string;
  answerAr: string;
  answerEn: string;
  category: string;
  difficulty: string;
  firstLetter?: string;
  tags?: string;
  createdAt?: string;
  usedInSession?: boolean;
  usedHistorically?: boolean;
}

export interface GameSettings {
  boardSize: BoardSize;
  language: Language;
  categories: string[];
  difficulty: Difficulty;
  timerSeconds: number;
  buzzMode: boolean;
  showLetterHint: boolean;
  showQuestionToAll: boolean;
  soundEnabled: boolean;
}

export interface Teams {
  red: string[];
  blue: string[];
}

export interface QuestionHistoryEntry {
  questionId: string;
  questionEn: string;
  questionAr: string;
  answerEn: string;
  answerAr: string;
  correct: boolean | null;
  teamAnswered: string | null;
  cellIndex: number | null;
  askedAt: string;
}

export interface GameState {
  roomCode: string | null;
  sessionId: string | null;
  hostId: string | null;
  grid: HexGrid | null;
  settings: GameSettings;
  players: Player[];
  teams: Teams;
  status: GameStatus;
  currentQuestion: Question | null;
  currentCell: number | null;
  buzzedPlayer: string | null;
  winner: TeamColor | null;
  questionHistory: QuestionHistoryEntry[];
  language: Language;
  isHost: boolean;
  myId: string | null;
  nickname: string | null;
}
