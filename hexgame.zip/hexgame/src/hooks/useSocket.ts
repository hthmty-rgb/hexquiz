// src/hooks/useSocket.ts
'use client';
import { useEffect, useRef } from 'react';
import { io, Socket } from 'socket.io-client';
import { useGameStore } from '@/store/gameStore';
import { HexGrid, Teams, Player, Question, QuestionHistoryEntry } from '@/types';

let socket: Socket | null = null;

export function getSocket(): Socket {
  if (!socket) {
    socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3001', {
      autoConnect: false,
    });
  }
  return socket;
}

export function useSocket() {
  const store = useGameStore();
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;
    
    const s = getSocket();
    if (!s.connected) s.connect();

    s.on('room_joined', (data: {
      grid: HexGrid;
      settings: any;
      teams: Teams;
      players: Player[];
      status: any;
      questionHistory: QuestionHistoryEntry[];
    }) => {
      store.setGrid(data.grid);
      store.setSettings(data.settings);
      store.setTeams(data.teams);
      store.setPlayers(data.players);
      store.setStatus(data.status);
      store.setHistory(data.questionHistory || []);
    });

    s.on('player_joined', ({ players }: { player: Player; players: Player[] }) => {
      store.setPlayers(players);
    });

    s.on('player_left', ({ players }: { players: Player[] }) => {
      store.setPlayers(players);
    });

    s.on('teams_updated', (teams: Teams) => {
      store.setTeams(teams);
    });

    s.on('game_started', ({ grid, settings }: { grid: HexGrid; settings: any }) => {
      store.setGrid(grid);
      store.setSettings(settings);
      store.setStatus('playing');
    });

    s.on('question_selected', ({ question, cellId }: { question: Question; cellId: number; letter: string }) => {
      store.setCurrentQuestion(question);
      store.setCurrentCell(cellId);
      store.setBuzzedPlayer(null);
    });

    s.on('player_buzzed', ({ playerId }: { playerId: string; nickname: string }) => {
      store.setBuzzedPlayer(playerId);
    });

    s.on('cell_captured', ({ grid }: { cellId: number; team: string; grid: any[] }) => {
      const current = useGameStore.getState().grid;
      if (current) store.setGrid({ ...current, cells: grid });
      store.setCurrentQuestion(null);
      store.setCurrentCell(null);
    });

    s.on('answer_wrong', () => {
      store.setCurrentQuestion(null);
      store.setCurrentCell(null);
    });

    s.on('game_won', ({ winner, grid }: { winner: any; grid: any[] }) => {
      const current = useGameStore.getState().grid;
      if (current) store.setGrid({ ...current, cells: grid });
      store.setWinner(winner);
      store.setStatus('finished');
    });

    s.on('question_skipped', () => {
      store.setCurrentQuestion(null);
      store.setCurrentCell(null);
      store.setBuzzedPlayer(null);
    });

    s.on('game_reset', ({ grid }: { grid: HexGrid }) => {
      store.setGrid(grid);
      store.setStatus('playing');
      store.setCurrentQuestion(null);
      store.setCurrentCell(null);
      store.setBuzzedPlayer(null);
      store.setWinner(null);
      store.setHistory([]);
    });

    s.on('history_updated', ({ history }: { history: QuestionHistoryEntry[] }) => {
      store.setHistory(history);
    });

    return () => {
      // Don't disconnect on unmount to persist across navigation
    };
  }, []);

  return getSocket();
}
